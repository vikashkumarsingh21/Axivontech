import type { Metadata } from "next";
import "./globals.css";
import { NovaCartProvider } from "@/context/NovaCartContext";
import NovaCartDemoStrip from "@/components/NovaCartDemoStrip";
import NovaCartHeader from "@/components/NovaCartHeader";
import NovaCartFooter from "@/components/NovaCartFooter";
import NovaCartToast from "@/components/NovaCartToast";

export const metadata: Metadata = {
  title: "NovaCart — Premium Lifestyle E-Commerce Application | Axivon Technologies",
  description:
    "A production-grade Next.js E-Commerce demonstration application crafted by Axivon Technologies. Features product discovery, category filtering, cart, wishlist, simulated checkout, order lifecycle tracking, and an isolated administrative console.",
  keywords: [
    "NovaCart",
    "Axivon Commerce",
    "E-Commerce App",
    "Next.js App Router",
    "Shopping Cart",
    "Admin Dashboard",
    "Axivon Technologies",
  ],
  icons: {
    icon: "/favicon.ico",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="h-full scroll-smooth">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5" />
      </head>
      <body className="h-full bg-[#F7F7F2] text-[#1C1D1A] font-sans antialiased selection:bg-[#D8F16A] selection:text-[#1C1D1A]">
        <NovaCartProvider>
          <div className="novacart-theme demo-light-theme min-h-screen flex flex-col">
            {/* Top Showcase Context Bar */}
            <NovaCartDemoStrip />

            {/* Store Header Navigation */}
            <NovaCartHeader />

            {/* Main Application Body */}
            <main className="flex-1">{children}</main>

            {/* Store Footer */}
            <NovaCartFooter />

            {/* Toast Notifications */}
            <NovaCartToast />
          </div>
        </NovaCartProvider>
      </body>
    </html>
  );
}
