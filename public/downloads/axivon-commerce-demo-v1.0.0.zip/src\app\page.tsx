import React from "react";
import NovaCartHero from "@/components/NovaCartHero";
import NovaCartCategoryGrid from "@/components/NovaCartCategoryGrid";
import NovaCartFeaturedSection from "@/components/NovaCartFeaturedSection";
import NovaCartEditorialStory from "@/components/NovaCartEditorialStory";
import NovaCartValuePillars from "@/components/NovaCartValuePillars";

export default function NovaCartHomePage() {
  return (
    <>
      {/* 1. Hero Showcase */}
      <NovaCartHero />

      {/* 2. Shop by Category Discovery Grid */}
      <NovaCartCategoryGrid />

      {/* 3. Featured Products & New Arrivals Grid */}
      <NovaCartFeaturedSection />

      {/* 4. Editorial Narrative and Brand Ethos */}
      <NovaCartEditorialStory />

      {/* 5. Value Pillars */}
      <NovaCartValuePillars />
    </>
  );
}
