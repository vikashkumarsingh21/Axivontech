"use client";

import React, { useState } from "react";
import Link from "next/link";
import { LayoutDashboard, RotateCcw, ExternalLink, Sparkles, Check } from "lucide-react";
import { resetDemoStoreData } from "@/data/novacart-store-data";

export default function NovaCartDemoStrip() {
  const [resetting, setResetting] = useState(false);
  const [resetDone, setResetDone] = useState(false);

  const handleReset = () => {
    if (confirm("Reset all demo orders, custom products, and cart to default state?")) {
      setResetting(true);
      resetDemoStoreData();
      setResetDone(true);
      setTimeout(() => {
        window.location.reload();
      }, 600);
    }
  };

  return (
    <aside
      aria-label="Standalone Demo Bar"
      className="sticky top-0 z-50 w-full border-b border-[#DCDDD5] bg-[#E8EBE3]/95 text-[#1C1D1A] shadow-xs backdrop-blur-md transition-all"
    >
      <div className="mx-auto flex h-9.5 max-w-7xl items-center justify-between gap-3 px-4 text-xs sm:px-6 lg:px-8">
        {/* Left: Brand & Local Mode Indicator */}
        <div className="flex items-center gap-2.5">
          <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="font-mono text-[11px] font-semibold uppercase tracking-wider text-[#1C1D1A]">
            Axivon Commerce <span className="text-[#696D66]">v1.0.0</span> (Local Standalone Demo)
          </span>
        </div>

        {/* Right: Quick actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={handleReset}
            disabled={resetting}
            className="group inline-flex items-center gap-1.5 rounded-full border border-[#DCDDD5] bg-white px-2.5 py-1 text-[11px] font-semibold text-[#1C1D1A] shadow-xs transition-all hover:bg-[#F7F7F2] active:scale-95"
            title="Reset demo data to default baseline"
          >
            {resetDone ? (
              <Check className="h-3 w-3 text-emerald-600" />
            ) : (
              <RotateCcw className={"h-3 w-3 text-[#696D66] " + (resetting ? "animate-spin" : "")} />
            )}
            <span className="hidden sm:inline">{resetDone ? "Reset Complete" : "Reset Demo Data"}</span>
          </button>

          <Link
            href="/admin"
            className="group inline-flex items-center gap-1.5 rounded-full border border-[#DCDDD5] bg-white px-2.5 py-1 text-[11px] font-semibold text-[#1C1D1A] shadow-xs transition-all hover:bg-[#F7F7F2]"
            title="Open isolated demo store admin console"
          >
            <LayoutDashboard className="h-3 w-3 text-[#1C1D1A]" />
            <span className="hidden sm:inline">Store Admin</span>
          </Link>

          <a
            href="https://axivontech.in/contact?project=NovaCart"
            target="_blank"
            rel="noopener noreferrer"
            className="group inline-flex items-center gap-1.5 rounded-full bg-[#1C1D1A] px-3 py-1 text-[11px] font-semibold text-white shadow-xs transition-all duration-200 hover:bg-[#343630]"
          >
            <Sparkles className="h-3 w-3 text-[#D8F16A]" />
            <span>Axivon Tech</span>
            <ExternalLink className="h-3 w-3 opacity-60" />
          </a>
        </div>
      </div>
    </aside>
  );
}
