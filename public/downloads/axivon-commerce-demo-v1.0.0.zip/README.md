# Axivon Commerce (NovaCart Edition) — Standalone Demonstration Package

> **Engineered by [Axivon Technologies](https://axivontech.in)**  
> Production-Grade Next.js App Router E-Commerce Application Architecture

---

## 🛍️ Overview

**Axivon Commerce (NovaCart Edition)** is a complete, realistic, modern e-commerce application designed to demonstrate the frontend architecture, state management, checkout simulation, and back-office management capabilities engineered by Axivon Technologies.

This standalone package runs independently on your local machine with **zero database setup required**. All orders, cart states, wishlists, and product modifications persist seamlessly in your browser's local storage with a built-in one-click **Reset Demo Data** mechanism.

---

## ⚡ Quick Start (Run in 2 Minutes)

### Prerequisites
- **Node.js**: `>= 18.18.0` (Node 20+ LTS recommended)
- **Package Manager**: `npm` (or `pnpm` / `yarn`)

### Installation & Execution

```bash
# 1. Unzip the downloaded package
unzip axivon-commerce-demo-v1.0.0.zip -d axivon-commerce-demo
cd axivon-commerce-demo

# 2. Install dependencies
npm install

# 3. Start the local development server
npm run dev
```

Open your browser and navigate to:  
👉 **[http://localhost:3000](http://localhost:3000)**

---

## 🗺️ Application Routes

### Customer Storefront
| Route | Description |
|---|---|
| `/` | Hero showcase, category discovery, featured collection, and value pillars |
| `/shop` | Full catalog browsing, multi-category filters, sorting (price, newest, name) |
| `/category/[slug]` | Filtered category views (Fashion, Bags & Travel, Home & Living, Tech) |
| `/products/[slug]` | Product detail view, multi-angle gallery, color/variant selector, accordion specs |
| `/cart` | Interactive cart line items, quantity adjustment, promo code engine, free shipping bar |
| `/wishlist` | Saved items gallery with instant 'Move to Cart' action |
| `/search` | Real-time catalog search with instant keyboard navigation |
| `/checkout` | Multi-step demo checkout with billing/shipping address, shipping method, and card simulation |
| `/order-confirmation` | Dynamic receipt view with tracking code, order breakdown, and delivery estimate |
| `/account` | Customer profile, address book, and live order tracking history |

### Store Administration Console
| Route | Description |
|---|---|
| `/admin` | **Store Admin Dashboard** with 5 functional management tabs: |
| — *Overview* | Real-time KPI cards (Gross Revenue, Active Orders, Average Order Value, Total Customers) |
| — *Catalog* | Product inventory table, live search, stock toggling, add new product modal, product editing, deletion |
| — *Orders* | Live order stream, status lifecycle progression (`PENDING` ➔ `PROCESSING` ➔ `SHIPPED` ➔ `DELIVERED`), order inspector modal |
| — *Inventory* | Stock health alerts, Low Stock & Out of Stock indicators, quick stock level adjustments |
| — *Customers* | Customer directory, order counts, lifetime spend analytics |
| — *Reset Engine* | Confirmed **Reset Demo Data** action that restores seed state in 1 click |

---

## 🛠️ Architecture & Tech Stack

- **Framework**: Next.js 15+ (App Router architecture)
- **UI Library**: React 19 (Server & Client Components)
- **Styling**: Tailwind CSS v4 (with custom porcelain/citrus lifestyle design system)
- **Icons**: Lucide React
- **Animations**: Framer Motion
- **State Management**: React Context (`NovaCartContext`) + LocalStorage Persistence Engine
- **Image Assets**: 52 high-resolution, local lifestyle product photographs included directly in `public/images/demo-projects/novacart/`

---

## 🔒 Security & Isolation Note

- **Zero External Production Dependencies**: This demonstration package operates completely isolated from Axivon's live production database and CRM endpoints.
- **Mock Payment Safety**: The checkout simulation requires no real payment processing credentials. Test cards and addresses are purely illustrative.
- **Privacy by Design**: All customer accounts and orders created during testing exist strictly within your browser's local sandbox.

---

## 💼 Custom Software Development

Need a custom enterprise e-commerce platform, multi-vendor marketplace, headless Shopify setup, or high-performance Next.js application tailored to your business?

- **Website**: [https://axivontech.in](https://axivontech.in)
- **Consultation**: [https://axivontech.in/contact](https://axivontech.in/contact)
- **Email**: `contact@axivontech.in`

© 2026 Axivon Technologies. All rights reserved.
